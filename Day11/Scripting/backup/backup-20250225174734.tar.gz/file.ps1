write-host "Hello World"
$name = "hello world"
write-host $name 
Get-ComputerInfo
Get-ChildItem C:\Users
$name = Read-Host "enter your name"
Write-Host "Hello, $name!"

